/*
 * FreeRTOSConfig.h
 *
 * Target    : Raspberry Pi Pico — RP2040 (ARM Cortex-M0+ @ 125 MHz)
 * Kernel    : FreeRTOS v11.3.0
 * SDK       : Pico SDK 2.2.0
 * Port      : portable/ThirdParty/GCC/RP2040
 * Heap      : heap_4
 * Stdio     : USB CDC
 * Cores     : Single-core (Core 0 only)
 *
 * Every macro is explained inline.
 */

#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

/* ============================================================================
 *  1. CORE / SCHEDULER
 * ============================================================================
 *
 * configNUMBER_OF_CORES
 *   How many cores the FreeRTOS scheduler manages.
 *   1 = single-core (only Core 0).  2 = SMP across both Cortex-M0+ cores.
 *   Single-core is simpler and avoids inter-core locking overhead.
 */
#define configNUMBER_OF_CORES                   1

/*
 * configUSE_PREEMPTION
 *   1 = Preemptive scheduler: a higher-priority task that becomes ready will
 *       immediately preempt the currently running lower-priority task.
 *   0 = Cooperative: tasks only switch when they explicitly yield or block.
 *   Preemptive is the standard choice for real-time systems.
 */
#define configUSE_PREEMPTION                    1

/*
 * configUSE_TIME_SLICING
 *   1 = Tasks of equal priority take turns in round-robin fashion each tick.
 *   0 = The currently running task keeps running until it blocks or a higher-
 *       priority task becomes ready.
 *   Enabled so that multiple same-priority tasks share CPU time fairly.
 */
#define configUSE_TIME_SLICING                  1

/*
 * configCPU_CLOCK_HZ
 *   The CPU clock frequency in Hertz.  RP2040 defaults to 125 MHz.
 *   The kernel uses this to configure SysTick for the tick interrupt.
 */
#define configCPU_CLOCK_HZ                      125000000UL

/*
 * configTICK_RATE_HZ
 *   How many tick interrupts per second.  1000 = 1 ms tick resolution.
 *   Higher values give finer timing but increase interrupt overhead.
 *   1000 Hz is the industry standard for most RTOS applications.
 */
#define configTICK_RATE_HZ                      ((TickType_t)1000)

/*
 * configMAX_PRIORITIES
 *   The number of available priority levels.  Priority 0 is the lowest
 *   (idle task), priority (configMAX_PRIORITIES - 1) is the highest.
 *   8 levels is generous for most embedded projects.
 *   Memory cost: one ready-list per priority level (small).
 */
#define configMAX_PRIORITIES                    8

/*
 * configMINIMAL_STACK_SIZE
 *   Stack size (in StackType_t words, i.e., 4-byte units on Cortex-M0+)
 *   for the idle task and as the default minimum for other tasks.
 *   256 words = 1024 bytes — safe for Cortex-M0+ which has limited call depth.
 */
#define configMINIMAL_STACK_SIZE                ((configSTACK_DEPTH_TYPE)256)

/*
 * configMAX_TASK_NAME_LEN
 *   Maximum characters (including null terminator) for task names.
 *   Names are used for debugging (e.g., in vTaskList output).
 */
#define configMAX_TASK_NAME_LEN                 16

/*
 * configTICK_TYPE_WIDTH_IN_BITS
 *   Replaces the deprecated configUSE_16_BIT_TICKS macro.
 *   Acceptable values:
 *     TICK_TYPE_WIDTH_16_BITS — TickType_t is 16-bit (8/16-bit MCUs only).
 *     TICK_TYPE_WIDTH_32_BITS — TickType_t is 32-bit (recommended for 32-bit MCUs).
 *     TICK_TYPE_WIDTH_64_BITS — TickType_t is 64-bit (for very long uptimes).
 *
 *   FreeRTOS v11.x enforces: define EXACTLY ONE of configUSE_16_BIT_TICKS or
 *   configTICK_TYPE_WIDTH_IN_BITS — never both, never neither.
 *   We use the modern macro.  32-bit ticks allow ~49.7 days before wraparound
 *   at 1 kHz tick rate.  Also determines the number of bits available in
 *   Event Groups (24 usable bits with 32-bit ticks).
 */
#define configTICK_TYPE_WIDTH_IN_BITS           TICK_TYPE_WIDTH_32_BITS

/*
 * configIDLE_SHOULD_YIELD
 *   1 = When a task at idle priority (priority 0) is ready, the idle task
 *       yields immediately so the application task can run.
 *   0 = The idle task completes its full time slice before yielding.
 *   Enabled for better responsiveness of idle-priority tasks.
 */
#define configIDLE_SHOULD_YIELD                 1

/*
 * configSTACK_DEPTH_TYPE
 *   The C type used for stack depth values.  uint32_t is appropriate for
 *   32-bit Cortex-M0+ and avoids truncation issues.
 */
#define configSTACK_DEPTH_TYPE                  uint32_t

/* ============================================================================
 *  2. MEMORY ALLOCATION
 * ============================================================================
 *
 * configTOTAL_HEAP_SIZE
 *   Total bytes available to FreeRTOS for dynamic allocation (heap_4).
 *   RP2040 has 264 KB SRAM.  Reserving 64 KB here leaves ~200 KB for
 *   stack, globals, and the Pico SDK's own allocations.
 *   Increase if your application creates many tasks/queues.
 *   Decrease if you need more RAM for application buffers.
 */
#define configTOTAL_HEAP_SIZE                   ((size_t)(64 * 1024))

/*
 * configSUPPORT_DYNAMIC_ALLOCATION
 *   1 = Enable xTaskCreate(), xQueueCreate(), xSemaphoreCreate*(), etc.
 *   These allocate TCBs, stacks, and queue storage from the FreeRTOS heap.
 *   Required since we use heap_4 and xTaskCreate() in main.c.
 */
#define configSUPPORT_DYNAMIC_ALLOCATION        1

/*
 * configSUPPORT_STATIC_ALLOCATION
 *   0 = Disabled.  We don't use xTaskCreateStatic() in this project.
 *   Setting to 0 means we do NOT need to provide
 *   vApplicationGetIdleTaskMemory() or vApplicationGetTimerTaskMemory().
 *   Enable later if you want statically-allocated tasks.
 */
#define configSUPPORT_STATIC_ALLOCATION         0

/* ============================================================================
 *  2b. ADDITIONAL LIBRARY FEATURES
 * ============================================================================
 *
 * These macros control whether certain FreeRTOS sub-modules are compiled.
 * They default to 1 if not defined, but we define them explicitly for
 * clarity and to avoid relying on internal defaults.
 */

/*
 * configUSE_EVENT_GROUPS
 *   1 = Compile the Event Groups module (event_groups.c).
 *   Event Groups let multiple tasks synchronize on combinations of event
 *   bits.  The number of usable bits depends on configTICK_TYPE_WIDTH_IN_BITS:
 *     16-bit ticks → 8 event bits
 *     32-bit ticks → 24 event bits
 *   Requires configUSE_TIMERS = 1 and INCLUDE_xTimerPendFunctionCall = 1
 *   if you use xEventGroupSetBitsFromISR().
 */
#define configUSE_EVENT_GROUPS                  1

/*
 * configUSE_STREAM_BUFFERS
 *   1 = Compile the Stream Buffer and Message Buffer modules (stream_buffer.c).
 *   Stream Buffers are lightweight single-reader/single-writer byte streams,
 *   often used for ISR-to-task data transfer.
 *   Requires configUSE_TASK_NOTIFICATIONS = 1.
 */
#define configUSE_STREAM_BUFFERS                1

/*
 * configUSE_NEWLIB_REENTRANT
 *   1 = Allocate a Newlib _reent struct per task for thread-safe C library
 *       functions (printf, strtok, etc.).
 *   0 = Disabled.  Use a mutex around printf() calls instead (simpler).
 *   The Pico SDK's printf is lightweight and not fully Newlib-based,
 *   so we leave this off.  Enable if using full Newlib and experiencing
 *   crashes with concurrent C library calls.
 */
#define configUSE_NEWLIB_REENTRANT              0

/*
 * configUSE_APPLICATION_TASK_TAG
 *   1 = Allow assigning a "tag" (void* or function pointer) to each task
 *       via vTaskSetApplicationTaskTag().  Used for trace hooks or
 *       attaching per-task metadata.
 *   0 = Disabled — saves a void* per TCB.
 */
#define configUSE_APPLICATION_TASK_TAG           0

/*
 * configUSE_MINI_LIST_ITEM
 *   1 = Use a smaller MiniListItem_t for the end-marker in each list.
 *       Saves a small amount of RAM per list.
 *   0 = MiniListItem_t is the same as ListItem_t (avoids strict-aliasing
 *       issues with certain compiler/LTO configurations).
 *   Set to 0 to prevent GCC strict-aliasing optimization bugs in
 *   release builds (-O2/-O3) with LTO enabled.
 */
#define configUSE_MINI_LIST_ITEM                0

/* ============================================================================
 *  3. SYNCHRONIZATION PRIMITIVES
 * ============================================================================
 *
 * These enable the corresponding FreeRTOS synchronization objects.
 * Each one adds a small amount of code to the kernel binary.
 */

/*
 * configUSE_MUTEXES
 *   1 = Enable mutexes (xSemaphoreCreateMutex).
 *   Mutexes include priority inheritance to prevent priority inversion.
 */
#define configUSE_MUTEXES                       1

/*
 * configUSE_RECURSIVE_MUTEXES
 *   1 = Enable recursive mutexes (xSemaphoreCreateRecursiveMutex).
 *   A recursive mutex can be taken multiple times by the same task.
 *   Useful for reentrant code paths.
 */
#define configUSE_RECURSIVE_MUTEXES             1

/*
 * configUSE_COUNTING_SEMAPHORES
 *   1 = Enable counting semaphores (xSemaphoreCreateCounting).
 *   Used for resource counting (e.g., N available buffers) and
 *   event counting (e.g., items in a queue).
 */
#define configUSE_COUNTING_SEMAPHORES           1

/*
 * configUSE_QUEUE_SETS
 *   1 = Enable queue sets (xQueueCreateSet).
 *   Allows a task to block waiting on multiple queues/semaphores
 *   simultaneously.
 */
#define configUSE_QUEUE_SETS                    1

/*
 * configQUEUE_REGISTRY_SIZE
 *   Maximum number of queues/semaphores that can be registered with
 *   a name for kernel-aware debugging (e.g., in SEGGER SystemView).
 *   Only useful during development; set to 0 to save RAM in production.
 */
#define configQUEUE_REGISTRY_SIZE               8

/* ============================================================================
 *  4. TASK NOTIFICATIONS
 * ============================================================================
 *
 * configUSE_TASK_NOTIFICATIONS
 *   1 = Enable the lightweight task notification API.
 *   Task notifications are faster and use less RAM than binary semaphores.
 *   Each task gets configTASK_NOTIFICATION_ARRAY_ENTRIES notification slots.
 */
#define configUSE_TASK_NOTIFICATIONS            1

/*
 * configTASK_NOTIFICATION_ARRAY_ENTRIES
 *   Number of notification values per task.  Default is 1.
 *   3 gives flexibility (e.g., one for ISR signaling, one for inter-task,
 *   one spare).  Each entry costs 8 bytes per task.
 */
#define configTASK_NOTIFICATION_ARRAY_ENTRIES   3

/* ============================================================================
 *  5. SOFTWARE TIMERS
 * ============================================================================
 *
 * configUSE_TIMERS
 *   1 = Enable the software timer API (xTimerCreate, xTimerStart, etc.).
 *   FreeRTOS creates a dedicated "Timer Service" (daemon) task to process
 *   timer callbacks.  The priority and stack are configured below.
 */
#define configUSE_TIMERS                        1

/*
 * configTIMER_TASK_PRIORITY
 *   Priority of the timer daemon task.
 *   Set to (configMAX_PRIORITIES - 1) so timer callbacks execute at the
 *   highest priority and are not delayed by application tasks.
 */
#define configTIMER_TASK_PRIORITY               (configMAX_PRIORITIES - 1)

/*
 * configTIMER_QUEUE_LENGTH
 *   Length of the command queue the timer task reads from.
 *   Each xTimerStart/xTimerStop/etc. sends a command to this queue.
 *   10 is sufficient unless you start/stop many timers simultaneously.
 */
#define configTIMER_QUEUE_LENGTH                10

/*
 * configTIMER_TASK_STACK_DEPTH
 *   Stack depth (in words) for the timer daemon task.
 *   Timer callbacks execute in this task's context, so the stack must be
 *   large enough for the deepest callback.  512 words = 2 KB.
 */
#define configTIMER_TASK_STACK_DEPTH             512

/* ============================================================================
 *  6. CO-ROUTINES (Legacy — Disabled)
 * ============================================================================
 *
 * Co-routines are a legacy FreeRTOS feature.  Tasks are more flexible
 * and more widely used.  Kept at 0 for all new projects.
 */
#define configUSE_CO_ROUTINES                   0
#define configMAX_CO_ROUTINE_PRIORITIES         2

/* ============================================================================
 *  7. HOOK (CALLBACK) FUNCTIONS
 * ============================================================================
 *
 * Hooks are user-defined functions called by the kernel at specific points.
 * Set to 1 only if you provide the corresponding function implementation.
 */

/*
 * configUSE_IDLE_HOOK
 *   1 = Kernel calls vApplicationIdleHook() on each iteration of the
 *       idle task loop.  Useful for putting the CPU to sleep.
 *   0 = No idle hook.  Safe default for beginners.
 */
#define configUSE_IDLE_HOOK                     0

/*
 * configUSE_TICK_HOOK
 *   1 = Kernel calls vApplicationTickHook() on every tick interrupt.
 *   Useful for periodic polling, but runs in ISR context — keep it fast.
 *   0 = No tick hook.
 */
#define configUSE_TICK_HOOK                     0

/*
 * configUSE_MALLOC_FAILED_HOOK
 *   1 = Kernel calls vApplicationMallocFailedHook() when pvPortMalloc()
 *       returns NULL.  HIGHLY RECOMMENDED for debugging heap exhaustion.
 *       You MUST define this function in your application code.
 */
#define configUSE_MALLOC_FAILED_HOOK          0

/*
 * configCHECK_FOR_STACK_OVERFLOW
 *   0 = No stack overflow checking (fastest, no safety).
 *   1 = Method 1: Checks if the stack pointer has gone past the stack end.
 *   2 = Method 2: Also writes a known pattern to the end of the stack and
 *       checks if it has been overwritten.  Most thorough.
 *   Method 2 catches more overflows but costs a few extra cycles per
 *   context switch.  Use 2 during development, 0 in production if needed.
 *   You MUST define vApplicationStackOverflowHook() when > 0.
 */
#define configCHECK_FOR_STACK_OVERFLOW          0

/*
 * configUSE_DAEMON_TASK_STARTUP_HOOK
 *   1 = Kernel calls vApplicationDaemonTaskStartupHook() once when the
 *       timer daemon task starts.  Useful for deferred initialization.
 *   0 = Not used.
 */
#define configUSE_DAEMON_TASK_STARTUP_HOOK      0

/* ============================================================================
 *  8. RUNTIME STATS & TRACE
 * ============================================================================
 *
 * These features help with debugging and performance analysis.
 */

/*
 * configGENERATE_RUN_TIME_STATS
 *   1 = Track how much CPU time each task consumes.
 *   Requires a high-resolution timer and two macros:
 *     portCONFIGURE_TIMER_FOR_RUN_TIME_STATS()
 *     portGET_RUN_TIME_COUNTER_VALUE()
 *   0 = Disabled (no overhead).  Enable later for profiling.
 */
#define configGENERATE_RUN_TIME_STATS           0

/*
 * configUSE_TRACE_FACILITY
 *   1 = Include uxTaskGetSystemState() and vTaskList() functions.
 *   These let you query task info (name, priority, state, stack high-water).
 *   Useful for debug shells.
 */
#define configUSE_TRACE_FACILITY                1

/*
 * configUSE_STATS_FORMATTING_FUNCTIONS
 *   1 = Include vTaskList() and vTaskGetRunTimeStats() which produce
 *       human-readable text tables.  Requires configUSE_TRACE_FACILITY = 1.
 */
#define configUSE_STATS_FORMATTING_FUNCTIONS    1

/* ============================================================================
 *  9. OPTIONAL / ADVANCED FEATURES
 * ============================================================================ */

/*
 * configUSE_PORT_OPTIMISED_TASK_SELECTION
 *   1 = Use hardware-assisted priority finding (e.g., CLZ instruction).
 *   0 = Use generic C algorithm.
 *   Cortex-M0+ does NOT have the CLZ instruction, so this MUST be 0.
 *   Setting to 1 on M0+ will cause a build error or undefined behavior.
 */
#define configUSE_PORT_OPTIMISED_TASK_SELECTION 0

/*
 * configUSE_TICKLESS_IDLE
 *   1 = Suppress tick interrupts when no tasks are ready, to save power.
 *   0 = Normal tick operation (tick fires every 1 ms regardless).
 *   Disable for now; enable for battery-powered applications later.
 */
#define configUSE_TICKLESS_IDLE                 0

/*
 * configENABLE_BACKWARD_COMPATIBILITY
 *   0 = Do not define deprecated type names (e.g., xTaskHandle).
 *   Forces use of modern names (TaskHandle_t, etc.).
 *   Best practice for new projects — avoids confusion.
 */
#define configENABLE_BACKWARD_COMPATIBILITY     0

/*
 * configNUM_THREAD_LOCAL_STORAGE_POINTERS
 *   Number of void* slots per task for thread-local storage.
 *   5 is generous; reduce to 0 if not used.
 */
#define configNUM_THREAD_LOCAL_STORAGE_POINTERS 5

/* ============================================================================
 *  10. OPTIONAL API FUNCTIONS
 * ============================================================================
 *
 * Each INCLUDE_* macro controls whether a specific API function is compiled
 * into the kernel.  Setting unused ones to 0 saves a small amount of flash.
 * Set all to 1 during learning so every API is available.
 */

#define INCLUDE_vTaskPrioritySet                1
#define INCLUDE_uxTaskPriorityGet               1
#define INCLUDE_vTaskDelete                     1
#define INCLUDE_vTaskSuspend                    1
#define INCLUDE_vTaskDelay                      1
#define INCLUDE_xTaskGetSchedulerState          1
#define INCLUDE_xTaskGetCurrentTaskHandle       1
#define INCLUDE_uxTaskGetStackHighWaterMark     1
#define INCLUDE_xTaskGetIdleTaskHandle          1
#define INCLUDE_eTaskGetState                   1
#define INCLUDE_xTimerPendFunctionCall          1
#define INCLUDE_xTaskAbortDelay                 1
#define INCLUDE_xTaskGetHandle                  1
#define INCLUDE_xTaskResumeFromISR              1

/*
 * INCLUDE_xTaskDelayUntil
 *   Replaces the deprecated INCLUDE_vTaskDelayUntil.
 *   The function was renamed from vTaskDelayUntil() to xTaskDelayUntil()
 *   (it now returns a BaseType_t).  FreeRTOS v11.x will error if you
 *   define BOTH the old and new macro simultaneously.
 */
#define INCLUDE_xTaskDelayUntil                 1

/* ---- Removed macros (and why) ----
 *
 * INCLUDE_xResumeFromISR:
 *   Not a real FreeRTOS INCLUDE macro.  The correct name is
 *   INCLUDE_xTaskResumeFromISR (defined above).  The kernel ignores
 *   the misspelled version silently, so it was dead code.
 *
 * INCLUDE_vTaskDelayUntil:
 *   Deprecated — replaced by INCLUDE_xTaskDelayUntil (see above).
 *   Defining both causes a compile error in FreeRTOS v11.x.
 *
 * INCLUDE_xEventGroupSetBitFromISR:
 *   No longer used by the FreeRTOS v11.x kernel to gate
 *   xEventGroupSetBitsFromISR().  That function is available when:
 *     configUSE_EVENT_GROUPS = 1
 *     configUSE_TIMERS = 1
 *     INCLUDE_xTimerPendFunctionCall = 1
 *   All three are already set in this file.
 */

/* ============================================================================
 *  11. INTERRUPT PRIORITIES (Cortex-M0+ on RP2040)
 * ============================================================================
 *
 * The Cortex-M0+ in RP2040 implements 2 priority bits, giving 4 levels:
 *   0x00  (highest — most urgent)
 *   0x40
 *   0x80
 *   0xC0  (lowest — least urgent)
 *
 * Priority values are stored in the TOP 2 bits of the 8-bit register.
 *
 * CRITICAL RULES:
 * - PendSV and SysTick must run at the LOWEST priority (0xC0) so they
 *   never preempt application ISRs.  configKERNEL_INTERRUPT_PRIORITY
 *   controls this.
 * - ISRs that call FreeRTOS API functions (ending in "FromISR") must
 *   have a priority value >= configMAX_SYSCALL_INTERRUPT_PRIORITY
 *   (numerically >= 0x40, i.e., urgency <= medium).
 * - ISRs with priority < configMAX_SYSCALL_INTERRUPT_PRIORITY (i.e.,
 *   0x00 = highest urgency) must NEVER call any FreeRTOS API.
 */

/* Lowest priority — used for PendSV and SysTick (kernel internals) */
#define configKERNEL_INTERRUPT_PRIORITY         (3 << 6)  /* 0xC0 */

/* Highest priority from which FreeRTOS "FromISR" APIs are safe to call */
#define configMAX_SYSCALL_INTERRUPT_PRIORITY    (1 << 6)  /* 0x40 */

/* ============================================================================
 *  12. ASSERT (Debug)
 * ============================================================================
 *
 * configASSERT is like assert() but for the kernel.  When an internal
 * consistency check fails, this macro fires.
 *
 * During development: prints the file/line, disables interrupts, and
 * hits a breakpoint (bkpt #0) so a debugger can catch it.
 * In production: you may replace this with a system reset.
 */
/*
 * NOTE: printf() is intentionally OMITTED from configASSERT.
 * When using USB CDC stdio (TinyUSB), printf() requires USB interrupts
 * to flush the TX buffer.  Since configASSERT disables all interrupts
 * first, printf() will block forever waiting for TinyUSB — causing an
 * infinite-loop deadlock instead of a clean halt.
 *
 * The bkpt #0 instruction triggers a debug breakpoint.  With a
 * debugger attached (picoprobe / OpenOCD), the call stack and
 * __FILE__/__LINE__ are visible in the debugger's backtrace.
 * Without a debugger, the CPU halts and the LED stops toggling,
 * which is the observable failure signal.
 */
#define configASSERT(x)                                                 \
    do {                                                                \
        if (!(x)) {                                                     \
            portDISABLE_INTERRUPTS();                                   \
            for (;;) { __asm volatile ("bkpt #0"); }                    \
        }                                                               \
    } while (0)

#endif /* FREERTOS_CONFIG_H */
