#include <stdio.h>
#include <stdlib.h>
#include "pico/stdlib.h"
#include "FreeRTOS.h"
#include "task.h"
#include "st7789.h"
#include "hardware/spi.h"
#include "hardware/adc.h"
#include "lvgl.h"

#define LED_PIN 25
#define _100MS pdMS_TO_TICKS(100)

void vTaskLed(void *pvParameters);
void vTaskDisplay(void *pvParameters);
void my_disp_flush(lv_disp_drv_t *disp_drv, const lv_area_t *area, lv_color_t *color_p);

int main()
{
    stdio_init_all();

    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);

    xTaskCreate(
        vTaskLed,
        "LED Task",
        256,
        NULL,
        1,
        NULL
    );
    xTaskCreate(
        vTaskDisplay,
        "Display",
        2048,
        NULL,
        2,
        NULL
    );
    vTaskStartScheduler();

    while (1)
    {
        // Should never reach here
    }
}

void vTaskLed(void *pvParameters)
{
    while (1)
    {
        gpio_put(LED_PIN, 1);
        vTaskDelay(_100MS);

        gpio_put(LED_PIN, 0);
        vTaskDelay(_100MS);
    }
}

#define TFT_WIDTH   240
#define TFT_HEIGHT  320

#define TFT_MOSI    19
#define TFT_SCK     18
#define TFT_CS      17
#define TFT_DC      20
#define TFT_RST     21
#define TFT_BL      22

// Snake Grid Settings
#define GRID_COLS   22
#define GRID_ROWS   22
#define CELL_SIZE   10

typedef enum {
    DIR_UP,
    DIR_DOWN,
    DIR_LEFT,
    DIR_RIGHT
} snake_dir_t;

typedef struct {
    int x;
    int y;
} position_t;

typedef enum {
    STATE_MENU,
    STATE_SNAKE,
    STATE_PONG,
    STATE_INVADERS
} app_state_t;

static app_state_t app_state = STATE_MENU;

// Menu variables
static lv_obj_t * menu_container = NULL;
static lv_obj_t * snake_card_obj = NULL;
static lv_obj_t * pong_card_obj = NULL;
static lv_obj_t * invader_card_obj = NULL;
static int menu_select = 0; // 0: Snake, 1: Brick Breaker, 2: Invaders
static uint32_t menu_cooldown_end = 0;

// Pong variables
static int paddle_x = 9;
#define PADDLE_WIDTH 4
static position_t ball_pos;
static int ball_dx = 1;
static int ball_dy = -1;
static lv_obj_t * paddle_obj = NULL;
static lv_obj_t * ball_obj = NULL;

#define BRICK_ROWS 4
#define BRICK_START_Y 4
static bool bricks_active[BRICK_ROWS][GRID_COLS];
static lv_obj_t * brick_objs[BRICK_ROWS][GRID_COLS];

// Space Invaders variables
#define INV_ROWS 3
#define INV_COLS 8
static bool inv_active[INV_ROWS][INV_COLS];
static lv_obj_t * inv_objs[INV_ROWS][INV_COLS];
static int inv_base_x = 1;   // top-left column of the formation
static int inv_base_y = 2;   // top-left row of the formation
static int inv_dx = 1;       // horizontal movement direction
static int ship_x = 10;      // ship center column
#define SHIP_WIDTH 3
static lv_obj_t * ship_obj = NULL;
static int bullet_x = -1;
static int bullet_y = -1;
static bool bullet_active = false;
static lv_obj_t * bullet_obj = NULL;
static uint32_t last_inv_move_tick = 0;
static uint32_t last_bullet_tick = 0;
static uint32_t last_autofire_tick = 0;

// Game container
static lv_obj_t * game_container = NULL;

#define MAX_SNAKE_LEN 100
static position_t snake_body[MAX_SNAKE_LEN];
static int snake_len = 3;
static snake_dir_t current_dir = DIR_RIGHT;
static snake_dir_t next_dir = DIR_RIGHT;
static position_t food_pos;
static int score = 0;
static int high_score = 0;
static bool game_over = false;

static lv_obj_t * snake_objs[MAX_SNAKE_LEN];
static lv_obj_t * food_obj = NULL;
static lv_obj_t * game_board = NULL;
static lv_obj_t * score_card = NULL;
static lv_obj_t * score_label = NULL;
static lv_obj_t * high_score_label = NULL;
static lv_obj_t * game_over_modal = NULL;
static lv_obj_t * countdown_label = NULL;
static lv_obj_t * title = NULL;
static int restart_counter = 3;
static uint32_t last_countdown_tick = 0;
static bool game_paused = false;
static lv_obj_t * pause_modal = NULL;

void my_disp_flush(lv_disp_drv_t *disp_drv, const lv_area_t *area, lv_color_t *color_p)
{
    st7789_caset(area->x1, area->x2);
    st7789_raset(area->y1, area->y2);
    
    uint32_t len = (area->x2 - area->x1 + 1) * (area->y2 - area->y1 + 1);
    st7789_write(color_p, len * sizeof(lv_color_t));
    
    lv_disp_flush_ready(disp_drv);
}

void init_snake() {
    for (int i = 0; i < MAX_SNAKE_LEN; i++) {
        if (snake_objs[i] != NULL) {
            lv_obj_del(snake_objs[i]);
            snake_objs[i] = NULL;
        }
    }
    
    if (pause_modal != NULL) {
        lv_obj_del(pause_modal);
        pause_modal = NULL;
    }
    game_paused = false;
    
    if (title != NULL) {
        lv_label_set_text(title, "PICO SNAKE");
    }
    
    snake_len = 3;
    current_dir = DIR_RIGHT;
    next_dir = DIR_RIGHT;
    
    for (int i = 0; i < snake_len; i++) {
        snake_body[i].x = 5 - i;
        snake_body[i].y = GRID_ROWS / 2;
        
        snake_objs[i] = lv_obj_create(game_board);
        lv_obj_set_size(snake_objs[i], CELL_SIZE - 1, CELL_SIZE - 1);
        if (i == 0) {
            lv_obj_set_style_bg_color(snake_objs[i], lv_color_make(34, 197, 94), 0); // Neon Green Head
        } else {
            if (i % 2 == 1) {
                lv_obj_set_style_bg_color(snake_objs[i], lv_color_make(14, 165, 233), 0); // Neon Sky Blue
            } else {
                lv_obj_set_style_bg_color(snake_objs[i], lv_color_make(168, 85, 247), 0); // Neon Purple
            }
        }
        lv_obj_set_style_bg_opa(snake_objs[i], LV_OPA_COVER, 0);
        lv_obj_set_style_radius(snake_objs[i], 3, 0);
        lv_obj_set_style_border_width(snake_objs[i], 0, 0);
        lv_obj_set_style_pad_all(snake_objs[i], 0, 0);
        
        lv_obj_set_pos(snake_objs[i], snake_body[i].x * CELL_SIZE, snake_body[i].y * CELL_SIZE);
    }
}

void spawn_food() {
    bool on_snake;
    do {
        on_snake = false;
        food_pos.x = rand() % GRID_COLS;
        food_pos.y = rand() % GRID_ROWS;
        
        for (int i = 0; i < snake_len; i++) {
            if (snake_body[i].x == food_pos.x && snake_body[i].y == food_pos.y) {
                on_snake = true;
                break;
            }
        }
    } while (on_snake);
    
    lv_obj_set_pos(food_obj, food_pos.x * CELL_SIZE, food_pos.y * CELL_SIZE);
}

void create_score_ui(lv_obj_t * parent) {
    score_card = lv_obj_create(parent);
    lv_obj_set_size(score_card, 220, 35);
    lv_obj_align(score_card, LV_ALIGN_TOP_MID, 0, 30);
    lv_obj_set_style_bg_color(score_card, lv_color_make(30, 41, 59), 0);
    lv_obj_set_style_border_color(score_card, lv_color_make(71, 85, 105), 0);
    lv_obj_set_style_border_width(score_card, 1, 0);
    lv_obj_set_style_radius(score_card, 6, 0);
    lv_obj_clear_flag(score_card, LV_OBJ_FLAG_SCROLLABLE);
    
    score_label = lv_label_create(score_card);
    lv_label_set_text(score_label, "Score: 0");
    lv_obj_set_style_text_color(score_label, lv_color_make(255, 255, 255), 0);
    lv_obj_align(score_label, LV_ALIGN_LEFT_MID, 10, 0);
    
    high_score_label = lv_label_create(score_card);
    lv_label_set_text(high_score_label, "High: 0");
    lv_obj_set_style_text_color(high_score_label, lv_color_make(148, 163, 184), 0);
    lv_obj_align(high_score_label, LV_ALIGN_RIGHT_MID, -10, 0);
}

void update_score_ui() {
    char score_buf[32];
    snprintf(score_buf, sizeof(score_buf), "Score: %d", score);
    lv_label_set_text(score_label, score_buf);
    
    char high_buf[32];
    snprintf(high_buf, sizeof(high_buf), "High: %d", high_score);
    lv_label_set_text(high_score_label, high_buf);
}

void handle_game_over() {
    game_over = true;
    if (score > high_score) {
        high_score = score;
    }
    
    last_countdown_tick = to_ms_since_boot(get_absolute_time());
    
    game_over_modal = lv_obj_create(game_container);
    lv_obj_set_size(game_over_modal, 230, 230);
    lv_obj_align(game_over_modal, LV_ALIGN_CENTER, 0, 25);
    lv_obj_set_style_bg_color(game_over_modal, lv_color_make(15, 23, 42), 0);
    lv_obj_set_style_bg_opa(game_over_modal, LV_OPA_80, 0);
    lv_obj_set_style_border_color(game_over_modal, lv_color_make(239, 68, 68), 0);
    lv_obj_set_style_border_width(game_over_modal, 2, 0);
    lv_obj_set_style_radius(game_over_modal, 12, 0);
    lv_obj_clear_flag(game_over_modal, LV_OBJ_FLAG_SCROLLABLE);
    
    lv_obj_t * go_title = lv_label_create(game_over_modal);
    lv_label_set_text(go_title, "GAME OVER");
    lv_obj_set_style_text_color(go_title, lv_color_make(239, 68, 68), 0);
    lv_obj_set_style_text_font(go_title, &lv_font_montserrat_14, 0);
    lv_obj_align(go_title, LV_ALIGN_TOP_MID, 0, 20);
    
    lv_obj_t * final_score_label = lv_label_create(game_over_modal);
    char score_buf[32];
    snprintf(score_buf, sizeof(score_buf), "Final Score: %d", score);
    lv_label_set_text(final_score_label, score_buf);
    lv_obj_set_style_text_color(final_score_label, lv_color_make(255, 255, 255), 0);
    lv_obj_align(final_score_label, LV_ALIGN_CENTER, 0, -10);
    
    countdown_label = lv_label_create(game_over_modal);
    lv_label_set_text(countdown_label, "Restarting in 3...");
    lv_obj_set_style_text_color(countdown_label, lv_color_make(148, 163, 184), 0);
    lv_obj_align(countdown_label, LV_ALIGN_BOTTOM_MID, 0, -20);
    
    restart_counter = 3;
}

void pause_game() {
    if (game_paused) return;
    game_paused = true;
    
    // Create pause overlay/modal on game_container
    pause_modal = lv_obj_create(game_container);
    lv_obj_set_size(pause_modal, 200, 100);
    lv_obj_align(pause_modal, LV_ALIGN_CENTER, 0, 25);
    lv_obj_set_style_bg_color(pause_modal, lv_color_make(15, 23, 42), 0); // slate-900
    lv_obj_set_style_bg_opa(pause_modal, LV_OPA_90, 0);
    lv_obj_set_style_border_color(pause_modal, lv_color_make(52, 211, 153), 0); // Emerald-400
    lv_obj_set_style_border_width(pause_modal, 2, 0);
    lv_obj_set_style_radius(pause_modal, 10, 0);
    lv_obj_clear_flag(pause_modal, LV_OBJ_FLAG_SCROLLABLE);
    
    lv_obj_t * pause_label = lv_label_create(pause_modal);
    lv_label_set_text(pause_label, "GAME PAUSED");
    lv_obj_set_style_text_color(pause_label, lv_color_make(52, 211, 153), 0);
    lv_obj_set_style_text_font(pause_label, &lv_font_montserrat_14, 0);
    lv_obj_align(pause_label, LV_ALIGN_CENTER, 0, 0);
}

void resume_game() {
    if (!game_paused) return;
    game_paused = false;
    
    if (pause_modal != NULL) {
        lv_obj_del(pause_modal);
        pause_modal = NULL;
    }
}

void update_menu_ui() {
    if (snake_card_obj == NULL || pong_card_obj == NULL || invader_card_obj == NULL) return;
    
    // Unhighlight all cards first
    lv_obj_t * cards[] = { snake_card_obj, pong_card_obj, invader_card_obj };
    for (int i = 0; i < 3; i++) {
        lv_obj_set_style_border_color(cards[i], lv_color_make(71, 85, 105), 0);
        lv_obj_set_style_border_width(cards[i], 1, 0);
        lv_obj_set_style_bg_color(cards[i], lv_color_make(15, 23, 42), 0);
    }
    
    // Highlight selected card
    if (menu_select == 0) {
        lv_obj_set_style_border_color(snake_card_obj, lv_color_make(52, 211, 153), 0);
        lv_obj_set_style_border_width(snake_card_obj, 3, 0);
        lv_obj_set_style_bg_color(snake_card_obj, lv_color_make(13, 59, 40), 0);
    } else if (menu_select == 1) {
        lv_obj_set_style_border_color(pong_card_obj, lv_color_make(34, 211, 238), 0);
        lv_obj_set_style_border_width(pong_card_obj, 3, 0);
        lv_obj_set_style_bg_color(pong_card_obj, lv_color_make(30, 58, 138), 0);
    } else {
        lv_obj_set_style_border_color(invader_card_obj, lv_color_make(251, 146, 60), 0); // Orange-400
        lv_obj_set_style_border_width(invader_card_obj, 3, 0);
        lv_obj_set_style_bg_color(invader_card_obj, lv_color_make(67, 20, 7), 0); // dark orange-900
    }
}

void cleanup_game_pointers() {
    for (int i = 0; i < MAX_SNAKE_LEN; i++) {
        snake_objs[i] = NULL;
    }
    food_obj = NULL;
    game_board = NULL;
    score_card = NULL;
    score_label = NULL;
    high_score_label = NULL;
    game_over_modal = NULL;
    countdown_label = NULL;
    title = NULL;
    paddle_obj = NULL;
    ball_obj = NULL;
    for (int r = 0; r < BRICK_ROWS; r++) {
        for (int c = 0; c < GRID_COLS; c += 2) {
            brick_objs[r][c] = NULL;
            brick_objs[r][c+1] = NULL;
        }
    }
    // Invaders cleanup
    for (int r = 0; r < INV_ROWS; r++) {
        for (int c = 0; c < INV_COLS; c++) {
            inv_objs[r][c] = NULL;
        }
    }
    ship_obj = NULL;
    bullet_obj = NULL;
    bullet_active = false;
}

void show_menu_ui() {
    app_state = STATE_MENU;
    game_paused = false;
    game_over = false;
    
    // Clean up game container if it exists
    if (game_container != NULL) {
        lv_obj_del(game_container);
        game_container = NULL;
    }
    cleanup_game_pointers();
    
    // Set menu selection cooldown (500ms) to prevent accidental double select
    menu_cooldown_end = to_ms_since_boot(get_absolute_time()) + 500;
    
    // Create menu container
    menu_container = lv_obj_create(lv_scr_act());
    lv_obj_set_size(menu_container, 240, 320);
    lv_obj_align(menu_container, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(menu_container, lv_color_make(15, 23, 42), 0); // slate-900
    lv_obj_set_style_bg_opa(menu_container, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(menu_container, 0, 0);
    lv_obj_set_style_pad_all(menu_container, 0, 0);
    lv_obj_clear_flag(menu_container, LV_OBJ_FLAG_SCROLLABLE);
    
    // Title
    lv_obj_t * m_title = lv_label_create(menu_container);
    lv_label_set_text(m_title, "PICO ARCADE");
    lv_obj_set_style_text_color(m_title, lv_color_make(217, 70, 239), 0); // Fuchsia-500
    lv_obj_set_style_text_font(m_title, &lv_font_montserrat_14, 0);
    lv_obj_align(m_title, LV_ALIGN_TOP_MID, 0, 35);
    
    // Subtitle
    lv_obj_t * m_sub = lv_label_create(menu_container);
    lv_label_set_text(m_sub, "Select a game:");
    lv_obj_set_style_text_color(m_sub, lv_color_make(148, 163, 184), 0); // slate-400
    lv_obj_align(m_sub, LV_ALIGN_TOP_MID, 0, 58);
    
    // Snake Card
    snake_card_obj = lv_obj_create(menu_container);
    lv_obj_set_size(snake_card_obj, 180, 45);
    lv_obj_align(snake_card_obj, LV_ALIGN_TOP_MID, 0, 85);
    lv_obj_set_style_radius(snake_card_obj, 8, 0);
    lv_obj_set_style_pad_all(snake_card_obj, 0, 0);
    lv_obj_clear_flag(snake_card_obj, LV_OBJ_FLAG_SCROLLABLE);
    
    lv_obj_t * snake_label = lv_label_create(snake_card_obj);
    lv_label_set_text(snake_label, "1. SNAKE GAME");
    lv_obj_set_style_text_color(snake_label, lv_color_make(255, 255, 255), 0);
    lv_obj_align(snake_label, LV_ALIGN_CENTER, 0, 0);
    
    // Brick Breaker Card
    pong_card_obj = lv_obj_create(menu_container);
    lv_obj_set_size(pong_card_obj, 180, 45);
    lv_obj_align(pong_card_obj, LV_ALIGN_TOP_MID, 0, 145);
    lv_obj_set_style_radius(pong_card_obj, 8, 0);
    lv_obj_set_style_pad_all(pong_card_obj, 0, 0);
    lv_obj_clear_flag(pong_card_obj, LV_OBJ_FLAG_SCROLLABLE);
    
    lv_obj_t * pong_label = lv_label_create(pong_card_obj);
    lv_label_set_text(pong_label, "2. BRICK BREAKER");
    lv_obj_set_style_text_color(pong_label, lv_color_make(255, 255, 255), 0);
    lv_obj_align(pong_label, LV_ALIGN_CENTER, 0, 0);
    
    // Space Invaders Card
    invader_card_obj = lv_obj_create(menu_container);
    lv_obj_set_size(invader_card_obj, 180, 45);
    lv_obj_align(invader_card_obj, LV_ALIGN_TOP_MID, 0, 205);
    lv_obj_set_style_radius(invader_card_obj, 8, 0);
    lv_obj_set_style_pad_all(invader_card_obj, 0, 0);
    lv_obj_clear_flag(invader_card_obj, LV_OBJ_FLAG_SCROLLABLE);
    
    lv_obj_t * inv_label = lv_label_create(invader_card_obj);
    lv_label_set_text(inv_label, "3. SPACE INVADERS");
    lv_obj_set_style_text_color(inv_label, lv_color_make(255, 255, 255), 0);
    lv_obj_align(inv_label, LV_ALIGN_CENTER, 0, 0);
    
    // Footer instruction
    lv_obj_t * footer = lv_label_create(menu_container);
    lv_label_set_text(footer, "Joystick: Up/Down\nBtn 1: Launch/Exit(Double)\nBtn 2: Pause/Play");
    lv_obj_set_style_text_color(footer, lv_color_make(148, 163, 184), 0); // slate-400
    lv_obj_set_style_text_align(footer, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(footer, LV_ALIGN_BOTTOM_MID, 0, -25);
    
    update_menu_ui();
}

void return_to_menu() {
    show_menu_ui();
}

void prepare_game_container() {
    // Delete menu container if it exists
    if (menu_container != NULL) {
        lv_obj_del(menu_container);
        menu_container = NULL;
    }
    
    // Create game container
    game_container = lv_obj_create(lv_scr_act());
    lv_obj_set_size(game_container, 240, 320);
    lv_obj_align(game_container, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_bg_color(game_container, lv_color_make(15, 23, 42), 0); // slate-900
    lv_obj_set_style_bg_opa(game_container, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(game_container, 0, 0);
    lv_obj_set_style_pad_all(game_container, 0, 0);
    lv_obj_clear_flag(game_container, LV_OBJ_FLAG_SCROLLABLE);
    
    // Game Title on game_container
    title = lv_label_create(game_container);
    lv_label_set_text(title, "PICO SNAKE");
    lv_obj_set_style_text_color(title, lv_color_make(52, 211, 153), 0); // Emerald-400
    lv_obj_set_style_text_font(title, &lv_font_montserrat_14, 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 8);
    
    // Scoreboard UI on game_container
    create_score_ui(game_container);
    
    // Game Board Container on game_container
    game_board = lv_obj_create(game_container);
    lv_obj_set_size(game_board, GRID_COLS * CELL_SIZE + 4, GRID_ROWS * CELL_SIZE + 4);
    lv_obj_align(game_board, LV_ALIGN_CENTER, 0, 25);
    lv_obj_set_style_bg_color(game_board, lv_color_make(30, 41, 59), 0); // slate-800
    lv_obj_set_style_border_color(game_board, lv_color_make(71, 85, 105), 0); // slate-600
    lv_obj_set_style_border_width(game_board, 2, 0);
    lv_obj_set_style_radius(game_board, 8, 0);
    lv_obj_set_style_pad_all(game_board, 0, 0);
    lv_obj_clear_flag(game_board, LV_OBJ_FLAG_SCROLLABLE);
}

void init_pong() {
    paddle_x = 9;
    ball_pos.x = 11;
    ball_pos.y = 15;
    ball_dx = 1;
    ball_dy = -1;
    
    if (paddle_obj != NULL) {
        lv_obj_del(paddle_obj);
        paddle_obj = NULL;
    }
    if (ball_obj != NULL) {
        lv_obj_del(ball_obj);
        ball_obj = NULL;
    }
    
    // Clear and delete old bricks if any
    for (int r = 0; r < BRICK_ROWS; r++) {
        for (int c = 0; c < GRID_COLS; c += 2) {
            if (brick_objs[r][c] != NULL) {
                lv_obj_del(brick_objs[r][c]);
                brick_objs[r][c] = NULL;
                brick_objs[r][c+1] = NULL;
            }
            bricks_active[r][c] = false;
            bricks_active[r][c+1] = false;
        }
    }
    
    if (title != NULL) {
        lv_label_set_text(title, "BRICK BREAKER");
    }
    
    if (pause_modal != NULL) {
        lv_obj_del(pause_modal);
        pause_modal = NULL;
    }
    game_paused = false;
    
    paddle_obj = lv_obj_create(game_board);
    lv_obj_set_size(paddle_obj, PADDLE_WIDTH * CELL_SIZE - 1, CELL_SIZE - 1);
    lv_obj_set_style_bg_color(paddle_obj, lv_color_make(234, 179, 8), 0); // Yellow-500
    lv_obj_set_style_bg_opa(paddle_obj, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(paddle_obj, 3, 0);
    lv_obj_set_style_border_width(paddle_obj, 0, 0);
    lv_obj_set_style_pad_all(paddle_obj, 0, 0);
    lv_obj_set_pos(paddle_obj, paddle_x * CELL_SIZE, 21 * CELL_SIZE);
    
    ball_obj = lv_obj_create(game_board);
    lv_obj_set_size(ball_obj, CELL_SIZE - 1, CELL_SIZE - 1);
    lv_obj_set_style_bg_color(ball_obj, lv_color_make(249, 115, 22), 0); // Orange-500
    lv_obj_set_style_bg_opa(ball_obj, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(ball_obj, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_border_width(ball_obj, 0, 0);
    lv_obj_set_style_pad_all(ball_obj, 0, 0);
    lv_obj_set_pos(ball_obj, ball_pos.x * CELL_SIZE, ball_pos.y * CELL_SIZE);

    // Initialize new bricks
    for (int r = 0; r < BRICK_ROWS; r++) {
        lv_color_t r_color;
        switch (r) {
            case 0: r_color = lv_color_make(244, 63, 94); break;  // Rose-500 (Red/Pink)
            case 1: r_color = lv_color_make(249, 115, 22); break; // Orange-500
            case 2: r_color = lv_color_make(234, 179, 8); break;  // Yellow-500
            case 3: r_color = lv_color_make(34, 197, 94); break;  // Green-500
            default: r_color = lv_color_make(255, 255, 255); break;
        }

        // Each brick is 2 cells wide, so we create bricks at columns: 0, 2, 4, ..., 20
        for (int c = 0; c < GRID_COLS; c += 2) {
            bricks_active[r][c] = true;
            bricks_active[r][c+1] = true; // both cells active

            lv_obj_t * b_obj = lv_obj_create(game_board);
            // Size: 2 cells wide, 1 cell high (minus padding)
            lv_obj_set_size(b_obj, 2 * CELL_SIZE - 1, CELL_SIZE - 1);
            lv_obj_set_style_bg_color(b_obj, r_color, 0);
            lv_obj_set_style_bg_opa(b_obj, LV_OPA_COVER, 0);
            lv_obj_set_style_radius(b_obj, 2, 0);
            lv_obj_set_style_border_width(b_obj, 0, 0);
            lv_obj_set_style_pad_all(b_obj, 0, 0);
            lv_obj_set_pos(b_obj, c * CELL_SIZE, (BRICK_START_Y + r) * CELL_SIZE);

            brick_objs[r][c] = b_obj;
            brick_objs[r][c+1] = b_obj; // share the same LVGL object pointer
        }
    }
}

void update_pong() {
    if (game_over) return;
    
    // Compute candidate next position
    int next_x = ball_pos.x + ball_dx;
    int next_y = ball_pos.y + ball_dy;
    
    // Clamp and bounce off left/right walls
    if (next_x < 0) {
        next_x = 0;
        ball_dx = -ball_dx;
    } else if (next_x >= GRID_COLS) {
        next_x = GRID_COLS - 1;
        ball_dx = -ball_dx;
    }
    
    // Clamp and bounce off top wall
    if (next_y < 0) {
        next_y = 0;
        ball_dy = -ball_dy;
    }
    
    // Check brick collision at the candidate position
    bool hit_brick = false;
    if (next_y >= BRICK_START_Y && next_y < BRICK_START_Y + BRICK_ROWS) {
        int r = next_y - BRICK_START_Y;
        int c = next_x;
        if (c >= 0 && c < GRID_COLS && bricks_active[r][c]) {
            hit_brick = true;
            
            // Find the even-column anchor of this 2-cell brick
            int anchor_c = (c % 2 == 0) ? c : (c - 1);
            
            // Deactivate both cells
            bricks_active[r][anchor_c] = false;
            if (anchor_c + 1 < GRID_COLS) {
                bricks_active[r][anchor_c + 1] = false;
            }
            
            // Delete visual brick object (only once, via the anchor pointer)
            if (brick_objs[r][anchor_c] != NULL) {
                lv_obj_del(brick_objs[r][anchor_c]);
                brick_objs[r][anchor_c] = NULL;
                if (anchor_c + 1 < GRID_COLS) {
                    brick_objs[r][anchor_c + 1] = NULL;
                }
            }
            
            // Reflect ball vertically and bounce it back out of the brick row
            ball_dy = -ball_dy;
            next_y = ball_pos.y;  // stay at the previous Y (don't enter the brick)
            
            score += 20;
            update_score_ui();
        }
    }

    // Check if all bricks are cleared → respawn a new set
    if (hit_brick) {
        bool any_bricks = false;
        for (int r = 0; r < BRICK_ROWS && !any_bricks; r++) {
            for (int c = 0; c < GRID_COLS; c++) {
                if (bricks_active[r][c]) {
                    any_bricks = true;
                    break;
                }
            }
        }
        if (!any_bricks) {
            // Respawn bricks (keeps score, paddle, and ball)
            for (int r = 0; r < BRICK_ROWS; r++) {
                lv_color_t r_color;
                switch (r) {
                    case 0: r_color = lv_color_make(244, 63, 94); break;
                    case 1: r_color = lv_color_make(249, 115, 22); break;
                    case 2: r_color = lv_color_make(234, 179, 8); break;
                    case 3: r_color = lv_color_make(34, 197, 94); break;
                    default: r_color = lv_color_make(255, 255, 255); break;
                }
                for (int c = 0; c < GRID_COLS; c += 2) {
                    bricks_active[r][c] = true;
                    bricks_active[r][c+1] = true;
                    lv_obj_t * b_obj = lv_obj_create(game_board);
                    lv_obj_set_size(b_obj, 2 * CELL_SIZE - 1, CELL_SIZE - 1);
                    lv_obj_set_style_bg_color(b_obj, r_color, 0);
                    lv_obj_set_style_bg_opa(b_obj, LV_OPA_COVER, 0);
                    lv_obj_set_style_radius(b_obj, 2, 0);
                    lv_obj_set_style_border_width(b_obj, 0, 0);
                    lv_obj_set_style_pad_all(b_obj, 0, 0);
                    lv_obj_set_pos(b_obj, c * CELL_SIZE, (BRICK_START_Y + r) * CELL_SIZE);
                    brick_objs[r][c] = b_obj;
                    brick_objs[r][c+1] = b_obj;
                }
            }
        }
    }
    
    // Check paddle bounce or game over at the bottom
    if (next_y >= 21) {
        if (next_x >= paddle_x && next_x < paddle_x + PADDLE_WIDTH) {
            next_y = 20;
            ball_dy = -ball_dy;
            score += 10;
            update_score_ui();
        } else {
            handle_game_over();
            return;
        }
    }
    
    // Commit new position
    ball_pos.x = next_x;
    ball_pos.y = next_y;
    lv_obj_set_pos(ball_obj, ball_pos.x * CELL_SIZE, ball_pos.y * CELL_SIZE);
}

void launch_pong() {
    prepare_game_container();
    app_state = STATE_PONG;
    
    if (title != NULL) {
        lv_label_set_text(title, "BRICK BREAKER");
        lv_obj_set_style_text_color(title, lv_color_make(6, 182, 212), 0); // Cyan-500
    }
    if (game_board != NULL) {
        lv_obj_set_style_border_color(game_board, lv_color_make(236, 72, 153), 0); // Pink-500 border
    }
    
    score = 0;
    update_score_ui();
    init_pong();
}

void init_invaders() {
    // Cleanup old objects
    for (int r = 0; r < INV_ROWS; r++) {
        for (int c = 0; c < INV_COLS; c++) {
            if (inv_objs[r][c] != NULL) {
                lv_obj_del(inv_objs[r][c]);
                inv_objs[r][c] = NULL;
            }
            inv_active[r][c] = false;
        }
    }
    if (ship_obj != NULL) { lv_obj_del(ship_obj); ship_obj = NULL; }
    if (bullet_obj != NULL) { lv_obj_del(bullet_obj); bullet_obj = NULL; }
    bullet_active = false;
    
    if (pause_modal != NULL) { lv_obj_del(pause_modal); pause_modal = NULL; }
    game_paused = false;
    
    if (title != NULL) lv_label_set_text(title, "SPACE INVADERS");
    
    // Reset formation position
    inv_base_x = 1;
    inv_base_y = 2;
    inv_dx = 1;
    ship_x = 10;
    last_inv_move_tick = 0;
    last_bullet_tick = 0;
    last_autofire_tick = 0;
    
    // Colors per row
    lv_color_t row_colors[INV_ROWS];
    row_colors[0] = lv_color_make(244, 63, 94);  // Rose-500
    row_colors[1] = lv_color_make(168, 85, 247);  // Violet-500
    row_colors[2] = lv_color_make(14, 165, 233);  // Sky-500
    
    // Create invader objects — each invader is 2 cells wide, spaced 2.5 cells apart
    for (int r = 0; r < INV_ROWS; r++) {
        for (int c = 0; c < INV_COLS; c++) {
            inv_active[r][c] = true;
            int gx = inv_base_x + c * 2 + (c / 2); // stagger with small gap
            int gy = inv_base_y + r * 2;
            
            inv_objs[r][c] = lv_obj_create(game_board);
            lv_obj_set_size(inv_objs[r][c], CELL_SIZE - 1, CELL_SIZE - 1);
            lv_obj_set_style_bg_color(inv_objs[r][c], row_colors[r], 0);
            lv_obj_set_style_bg_opa(inv_objs[r][c], LV_OPA_COVER, 0);
            lv_obj_set_style_radius(inv_objs[r][c], 2, 0);
            lv_obj_set_style_border_width(inv_objs[r][c], 0, 0);
            lv_obj_set_style_pad_all(inv_objs[r][c], 0, 0);
            lv_obj_set_pos(inv_objs[r][c], gx * CELL_SIZE, gy * CELL_SIZE);
        }
    }
    
    // Create ship (Yellow, 3 cells wide)
    ship_obj = lv_obj_create(game_board);
    lv_obj_set_size(ship_obj, SHIP_WIDTH * CELL_SIZE - 1, CELL_SIZE - 1);
    lv_obj_set_style_bg_color(ship_obj, lv_color_make(34, 197, 94), 0); // Green-500
    lv_obj_set_style_bg_opa(ship_obj, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(ship_obj, 3, 0);
    lv_obj_set_style_border_width(ship_obj, 0, 0);
    lv_obj_set_style_pad_all(ship_obj, 0, 0);
    lv_obj_set_pos(ship_obj, ship_x * CELL_SIZE, 21 * CELL_SIZE);
    
    // Pre-create bullet object (hidden initially)
    bullet_obj = lv_obj_create(game_board);
    lv_obj_set_size(bullet_obj, CELL_SIZE / 2, CELL_SIZE - 1);
    lv_obj_set_style_bg_color(bullet_obj, lv_color_make(250, 204, 21), 0); // Yellow-400
    lv_obj_set_style_bg_opa(bullet_obj, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(bullet_obj, 2, 0);
    lv_obj_set_style_border_width(bullet_obj, 0, 0);
    lv_obj_set_style_pad_all(bullet_obj, 0, 0);
    lv_obj_add_flag(bullet_obj, LV_OBJ_FLAG_HIDDEN);
}

void update_invaders() {
    if (game_over) return;
    
    uint32_t now = to_ms_since_boot(get_absolute_time());
    
    // Auto-fire every 600ms
    if (!bullet_active && (now - last_autofire_tick >= 600)) {
        last_autofire_tick = now;
        bullet_active = true;
        bullet_x = ship_x + 1; // center of ship
        bullet_y = 20;
        lv_obj_clear_flag(bullet_obj, LV_OBJ_FLAG_HIDDEN);
        lv_obj_set_pos(bullet_obj, bullet_x * CELL_SIZE + CELL_SIZE / 4, bullet_y * CELL_SIZE);
        last_bullet_tick = now;
    }
    
    // Move bullet upward every 80ms
    if (bullet_active && (now - last_bullet_tick >= 80)) {
        last_bullet_tick = now;
        bullet_y--;
        
        if (bullet_y < 0) {
            bullet_active = false;
            lv_obj_add_flag(bullet_obj, LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_set_pos(bullet_obj, bullet_x * CELL_SIZE + CELL_SIZE / 4, bullet_y * CELL_SIZE);
            
            // Check collision with invaders
            for (int r = 0; r < INV_ROWS; r++) {
                for (int c = 0; c < INV_COLS; c++) {
                    if (!inv_active[r][c]) continue;
                    int gx = inv_base_x + c * 2 + (c / 2);
                    int gy = inv_base_y + r * 2;
                    if (bullet_x == gx && bullet_y == gy) {
                        // Hit!
                        inv_active[r][c] = false;
                        if (inv_objs[r][c] != NULL) {
                            lv_obj_del(inv_objs[r][c]);
                            inv_objs[r][c] = NULL;
                        }
                        bullet_active = false;
                        lv_obj_add_flag(bullet_obj, LV_OBJ_FLAG_HIDDEN);
                        score += 20;
                        update_score_ui();
                        goto bullet_done;
                    }
                }
            }
        }
    }
    bullet_done:
    
    // Move invader formation every 500ms
    if (now - last_inv_move_tick >= 500) {
        last_inv_move_tick = now;
        
        // Find rightmost and leftmost active invader columns
        int min_gx = 99, max_gx = -1;
        bool any_alive = false;
        for (int r = 0; r < INV_ROWS; r++) {
            for (int c = 0; c < INV_COLS; c++) {
                if (inv_active[r][c]) {
                    any_alive = true;
                    int gx = inv_base_x + c * 2 + (c / 2);
                    if (gx < min_gx) min_gx = gx;
                    if (gx > max_gx) max_gx = gx;
                }
            }
        }
        
        if (!any_alive) {
            // All invaders destroyed — respawn a new wave
            init_invaders();
            return;
        }
        
        // Check if formation should descend
        bool descend = false;
        if (inv_dx > 0 && max_gx >= GRID_COLS - 1) {
            inv_dx = -1;
            descend = true;
        } else if (inv_dx < 0 && min_gx <= 0) {
            inv_dx = 1;
            descend = true;
        }
        
        if (descend) {
            inv_base_y++;
        } else {
            inv_base_x += inv_dx;
        }
        
        // Update positions and check game over
        for (int r = 0; r < INV_ROWS; r++) {
            for (int c = 0; c < INV_COLS; c++) {
                if (!inv_active[r][c]) continue;
                int gx = inv_base_x + c * 2 + (c / 2);
                int gy = inv_base_y + r * 2;
                
                // Invaders reached ship row — game over
                if (gy >= 20) {
                    handle_game_over();
                    return;
                }
                
                lv_obj_set_pos(inv_objs[r][c], gx * CELL_SIZE, gy * CELL_SIZE);
            }
        }
    }
}

void launch_invaders() {
    prepare_game_container();
    app_state = STATE_INVADERS;
    
    if (title != NULL) {
        lv_label_set_text(title, "SPACE INVADERS");
        lv_obj_set_style_text_color(title, lv_color_make(251, 146, 60), 0); // Orange-400
    }
    if (game_board != NULL) {
        lv_obj_set_style_border_color(game_board, lv_color_make(168, 85, 247), 0); // Violet-500 border
    }
    
    score = 0;
    update_score_ui();
    init_invaders();
}

void launch_snake() {
    prepare_game_container();
    app_state = STATE_SNAKE;
    
    if (title != NULL) {
        lv_label_set_text(title, "PICO SNAKE");
        lv_obj_set_style_text_color(title, lv_color_make(245, 158, 11), 0); // Amber-500 (Yellow/Orange)
    }
    if (game_board != NULL) {
        lv_obj_set_style_border_color(game_board, lv_color_make(99, 102, 241), 0); // Indigo-500 border
    }
    
    // Food Object initialization on game_board (Neon Rose/Hot Pink)
    food_obj = lv_obj_create(game_board);
    lv_obj_set_size(food_obj, CELL_SIZE - 2, CELL_SIZE - 2);
    lv_obj_set_style_bg_color(food_obj, lv_color_make(244, 63, 94), 0); // Rose-500
    lv_obj_set_style_bg_opa(food_obj, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(food_obj, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_border_width(food_obj, 0, 0);
    lv_obj_set_style_pad_all(food_obj, 0, 0);
    
    score = 0;
    update_score_ui();
    init_snake();
    spawn_food();
}



void read_joystick() {
    adc_select_input(0); // X-axis (GP26)
    uint16_t x_val = adc_read();
    
    adc_select_input(1); // Y-axis (GP27)
    uint16_t y_val = adc_read();
    
    if (app_state == STATE_MENU) {
        // Menu selection navigation: Up/Down
        static uint32_t last_nav_tick = 0;
        uint32_t now = to_ms_since_boot(get_absolute_time());
        if (now - last_nav_tick >= 250) {
            if (y_val < 1000) {
                if (menu_select > 0) menu_select--;
                update_menu_ui();
                last_nav_tick = now;
            } else if (y_val > 3000) {
                if (menu_select < 2) menu_select++;
                update_menu_ui();
                last_nav_tick = now;
            }
        }
    } else if (app_state == STATE_SNAKE) {
        if (x_val < 1000) {
            if (current_dir != DIR_RIGHT) next_dir = DIR_LEFT;
        } else if (x_val > 3000) {
            if (current_dir != DIR_LEFT) next_dir = DIR_RIGHT;
        }
        if (y_val < 1000) {
            if (current_dir != DIR_DOWN) next_dir = DIR_UP;
        } else if (y_val > 3000) {
            if (current_dir != DIR_UP) next_dir = DIR_DOWN;
        }
    } else if (app_state == STATE_PONG) {
        static uint32_t last_paddle_tick = 0;
        uint32_t now = to_ms_since_boot(get_absolute_time());
        if (now - last_paddle_tick >= 40) {
            if (x_val < 1000) {
                if (paddle_x > 0) {
                    paddle_x--;
                    lv_obj_set_pos(paddle_obj, paddle_x * CELL_SIZE, 21 * CELL_SIZE);
                }
                last_paddle_tick = now;
            } else if (x_val > 3000) {
                if (paddle_x < GRID_COLS - PADDLE_WIDTH) {
                    paddle_x++;
                    lv_obj_set_pos(paddle_obj, paddle_x * CELL_SIZE, 21 * CELL_SIZE);
                }
                last_paddle_tick = now;
            }
        }
    } else if (app_state == STATE_INVADERS) {
        static uint32_t last_ship_tick = 0;
        uint32_t now = to_ms_since_boot(get_absolute_time());
        if (now - last_ship_tick >= 40) {
            if (x_val < 1000) {
                if (ship_x > 0) {
                    ship_x--;
                    lv_obj_set_pos(ship_obj, ship_x * CELL_SIZE, 21 * CELL_SIZE);
                }
                last_ship_tick = now;
            } else if (x_val > 3000) {
                if (ship_x < GRID_COLS - SHIP_WIDTH) {
                    ship_x++;
                    lv_obj_set_pos(ship_obj, ship_x * CELL_SIZE, 21 * CELL_SIZE);
                }
                last_ship_tick = now;
            }
        }
    }
}

void update_game() {
    if (game_over) return;
    
    current_dir = next_dir;
    
    position_t new_head = snake_body[0];
    switch (current_dir) {
        case DIR_UP:    new_head.y--; break;
        case DIR_DOWN:  new_head.y++; break;
        case DIR_LEFT:  new_head.x--; break;
        case DIR_RIGHT: new_head.x++; break;
    }
    
    // Copy to local stack integers for completely robust, cast-safe comparison
    int h_x = new_head.x;
    int h_y = new_head.y;
    
    // Check wall collision
    if (h_x < 0 || h_x >= 22 || h_y < 0 || h_y >= 22) {
        handle_game_over();
        return;
    }
    
    // Check self collision (start from index 1 to avoid checking head against itself)
    for (int i = 1; i < snake_len; i++) {
        if (snake_body[i].x == h_x && snake_body[i].y == h_y) {
            handle_game_over();
            return;
        }
    }
    
    bool ate_food = (h_x == food_pos.x && h_y == food_pos.y);
    
    if (ate_food) {
        if (snake_len < MAX_SNAKE_LEN) {
            for (int i = snake_len; i > 0; i--) {
                snake_body[i] = snake_body[i-1];
            }
            snake_body[0] = new_head;
            
            int new_idx = snake_len;
            snake_objs[new_idx] = lv_obj_create(game_board);
            lv_obj_set_size(snake_objs[new_idx], CELL_SIZE - 1, CELL_SIZE - 1);
            lv_obj_set_style_bg_color(snake_objs[new_idx], lv_color_make(16, 185, 129), 0);
            lv_obj_set_style_bg_opa(snake_objs[new_idx], LV_OPA_COVER, 0);
            lv_obj_set_style_radius(snake_objs[new_idx], 3, 0);
            lv_obj_set_style_border_width(snake_objs[new_idx], 0, 0);
            lv_obj_set_style_pad_all(snake_objs[new_idx], 0, 0);
            
            snake_len++;
        }
        
        score += 10;
        update_score_ui();
        spawn_food();
    } else {
        for (int i = snake_len - 1; i > 0; i--) {
            snake_body[i] = snake_body[i-1];
        }
        snake_body[0] = new_head;
    }
    
    for (int i = 0; i < snake_len; i++) {
        lv_obj_set_pos(snake_objs[i], snake_body[i].x * CELL_SIZE, snake_body[i].y * CELL_SIZE);
        if (i == 0) {
            lv_obj_set_style_bg_color(snake_objs[i], lv_color_make(34, 197, 94), 0); // Neon Green Head
        } else {
            if (i % 2 == 1) {
                lv_obj_set_style_bg_color(snake_objs[i], lv_color_make(14, 165, 233), 0); // Neon Sky Blue
            } else {
                lv_obj_set_style_bg_color(snake_objs[i], lv_color_make(168, 85, 247), 0); // Neon Purple
            }
        }
    }
    
    if (title != NULL) {
        char title_buf[32];
        snprintf(title_buf, sizeof(title_buf), "PICO SNAKE X:%d Y:%d", snake_body[0].x, snake_body[0].y);
        lv_label_set_text(title, title_buf);
    }
}

void vTaskDisplay(void *pvParameters)
{
    struct st7789_config lcd =
    {
        .spi = spi0,
        .gpio_din = TFT_MOSI,
        .gpio_clk = TFT_SCK,
        .gpio_cs = TFT_CS,
        .gpio_dc = TFT_DC,
        .gpio_rst = TFT_RST,
        .gpio_bl = TFT_BL
    };

    st7789_init(&lcd, TFT_WIDTH, TFT_HEIGHT);

    // Initialize ADC for joystick
    adc_init();
    adc_gpio_init(26);
    adc_gpio_init(27);

    // Initialize GPIO 1 for select/menu switch
    gpio_init(1);
    gpio_set_dir(1, GPIO_IN);
    gpio_pull_up(1);

    // Initialize GPIO 2 for dedicated pause switch
    gpio_init(2);
    gpio_set_dir(2, GPIO_IN);
    gpio_pull_up(2);

    // Seed random numbers using system time
    srand(to_ms_since_boot(get_absolute_time()));

    lv_init();

    #define DISP_BUF_SIZE (TFT_WIDTH * 10)
    static lv_color_t buf[DISP_BUF_SIZE];
    static lv_disp_draw_buf_t draw_buf;
    lv_disp_draw_buf_init(&draw_buf, buf, NULL, DISP_BUF_SIZE);

    static lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);
    disp_drv.draw_buf = &draw_buf;
    disp_drv.flush_cb = my_disp_flush;
    disp_drv.hor_res = TFT_WIDTH;
    disp_drv.ver_res = TFT_HEIGHT;
    lv_disp_drv_register(&disp_drv);

    // Show Main Menu initially
    show_menu_ui();

    uint32_t last_game_tick = 0;
    static bool last_btn_state = true;
    static bool last_pause_btn_state = true;
    static uint32_t click_window_start = 0;
    static int click_count = 0;

    while (1)
    {
        uint32_t now = to_ms_since_boot(get_absolute_time());

        // 1. Poll dedicated Pause button (GPIO 2)
        bool current_pause_btn_state = gpio_get(2);
        if (last_pause_btn_state && !current_pause_btn_state) {
            if (app_state != STATE_MENU && !game_over) {
                if (!game_paused) {
                    pause_game();
                } else {
                    resume_game();
                }
            }
            vTaskDelay(pdMS_TO_TICKS(40)); // Press debounce
        }
        last_pause_btn_state = current_pause_btn_state;

        // 2. Poll select/menu button (GPIO 1) with multi-click tracking
        bool current_btn_state = gpio_get(1);
        if (last_btn_state && !current_btn_state) {
            if (app_state == STATE_MENU) {
                // Check menu selection cooldown
                if (now >= menu_cooldown_end) {
                    if (menu_select == 0) {
                        launch_snake();
                    } else if (menu_select == 1) {
                        launch_pong();
                    } else {
                        launch_invaders();
                    }
                }
            } else {
                // In game, count clicks for returning to menu
                if (click_count == 0) {
                    click_window_start = now;
                }
                click_count++;
            }
            vTaskDelay(pdMS_TO_TICKS(40)); // Press debounce
        }
        last_btn_state = current_btn_state;

        // Process double click for GPIO 1 after window (350ms) expires
        if (app_state != STATE_MENU && click_count > 0 && (now - click_window_start >= 350)) {
            if (click_count == 2) {
                // 2 presses: Return to menu
                return_to_menu();
            }
            click_count = 0;
        }

        // Poll joystick unless game is paused
        if (app_state == STATE_MENU || !game_paused) {
            read_joystick();
        }

        if (app_state != STATE_MENU) {
            if (game_over) {
                if (now - last_countdown_tick >= 1000) {
                    last_countdown_tick = now;
                    restart_counter--;
                    if (restart_counter > 0) {
                        char count_buf[32];
                        snprintf(count_buf, sizeof(count_buf), "Restarting in %d...", restart_counter);
                        lv_label_set_text(countdown_label, count_buf);
                    } else {
                        if (game_over_modal != NULL) {
                            lv_obj_del(game_over_modal);
                            game_over_modal = NULL;
                        }
                        score = 0;
                        update_score_ui();
                        if (app_state == STATE_SNAKE) {
                            init_snake();
                            spawn_food();
                        } else if (app_state == STATE_PONG) {
                            init_pong();
                        } else if (app_state == STATE_INVADERS) {
                            init_invaders();
                        }
                        game_over = false;
                    }
                }
            } else {
                // Update game state
                if (!game_paused) {
                    if (app_state == STATE_SNAKE) {
                        if (now - last_game_tick >= 150) {
                            last_game_tick = now;
                            update_game();
                        }
                    } else if (app_state == STATE_PONG) {
                        if (now - last_game_tick >= 110) {
                            last_game_tick = now;
                            update_pong();
                        }
                    } else if (app_state == STATE_INVADERS) {
                        // Invaders uses its own internal tick timers
                        update_invaders();
                    }
                } else {
                    last_game_tick = now; // Keep tick current during pause
                }
            }
        }

        // Run LVGL timer tasks
        lv_timer_handler();

        vTaskDelay(pdMS_TO_TICKS(5));
    }
}