def build_pico_quick_reference(story):
    story.append(Paragraph("Raspberry Pi Pico SDK Quick Reference", ST_COVER_TITLE)) # Just as a nice title
    story.append(Spacer(1, 6*mm))
    story.append(HRFlowable(width="100%", thickness=1.5, color=C_ACCENT, spaceAfter=8, spaceBefore=0))
    # The sections use section_header which adds to TOC

    # ---------------------------------------------------------
    # 1. General GPIO Workflow
    # ---------------------------------------------------------
    story += section_header("1. General GPIO Workflow")
    story.append(Paragraph("Typical sequence for configuring and using a GPIO:", ST_BODY))
    story.append(Paragraph("1. Initialize the pin using gpio_init(pin).", ST_BODY))
    story.append(Paragraph("2. Select the pin function if necessary (normally gpio_init() configures it for standard GPIO/SIO).", ST_BODY))
    story.append(Paragraph("3. Set the direction using gpio_set_dir(pin, GPIO_OUT) or GPIO_IN.", ST_BODY))
    story.append(Paragraph("4. If configured as an input, enable gpio_pull_up() or gpio_pull_down() when required.", ST_BODY))
    story.append(Paragraph("5. Use gpio_put() to drive outputs.", ST_BODY))
    story.append(Paragraph("6. Use gpio_get() to read inputs.", ST_BODY))
    story.append(Paragraph("7. Configure interrupts only if needed.", ST_BODY))
    story.append(Spacer(1, 4*mm))
    
    apis = [
        ("gpio_init", 
         "Initializes a GPIO for (SIO) software control.<br/><b>Note:</b> Clears previous function and sets direction to input.",
         "void gpio_init(uint gpio);",
         [("gpio", "uint", "GPIO number")], "None"),
        ("gpio_set_dir", 
         "Sets the direction of a GPIO (in or out).<br/><b>Mistake:</b> Forgetting to call this makes outputs silently fail.",
         "void gpio_set_dir(uint gpio, bool out);",
         [("gpio", "uint", "GPIO number"), ("out", "bool", "true for out, false for in")], "None"),
        ("gpio_put", 
         "Drives a high or low value to an output GPIO.<br/><b>Note:</b> Only works if GPIO direction is out.",
         "void gpio_put(uint gpio, bool value);",
         [("gpio", "uint", "GPIO number"), ("value", "bool", "true for high, false for low")], "None"),
        ("gpio_get", 
         "Reads the logical state of a GPIO.<br/><b>Note:</b> Can read back output state or external input state.",
         "bool gpio_get(uint gpio);",
         [("gpio", "uint", "GPIO number")], "true (high) or false (low)"),
        ("gpio_pull_up", 
         "Enables the internal pull-up resistor.<br/><b>Note:</b> Useful for buttons connected to GND.",
         "void gpio_pull_up(uint gpio);",
         [("gpio", "uint", "GPIO number")], "None"),
        ("gpio_pull_down", 
         "Enables the internal pull-down resistor.",
         "void gpio_pull_down(uint gpio);",
         [("gpio", "uint", "GPIO number")], "None"),
        ("gpio_disable_pulls", 
         "Disables both pull-up and pull-down resistors.",
         "void gpio_disable_pulls(uint gpio);",
         [("gpio", "uint", "GPIO number")], "None"),
        ("gpio_set_function", 
         "Selects a specific hardware function for a GPIO (UART, SPI, I2C, PWM).<br/><b>Dependency:</b> Must be called before peripheral uses the pin.",
         "void gpio_set_function(uint gpio, enum gpio_function fn);",
         [("gpio", "uint", "GPIO number"), ("fn", "enum", "GPIO_FUNC_SPI, GPIO_FUNC_UART, etc.")], "None"),
        ("gpio_set_irq_enabled_with_callback", 
         "Enables a GPIO interrupt and registers a callback.<br/><b>Mistake:</b> There is only one GPIO callback for all pins. You must check which pin caused the IRQ inside the callback.",
         "void gpio_set_irq_enabled_with_callback(uint gpio, uint32_t event_mask, bool enabled, gpio_irq_callback_t callback);",
         [("gpio", "uint", "GPIO number"), ("event_mask", "uint32_t", "e.g., GPIO_IRQ_EDGE_RISE"), ("enabled", "bool", "true to enable"), ("callback", "gpio_irq_callback_t", "Function pointer")], "None")
    ]
    for a in apis: story += api_entry(*a)
    story.append(PageBreak())

    # ---------------------------------------------------------
    # 2. Timing
    # ---------------------------------------------------------
    story += section_header("2. Timing")
    story.append(Paragraph("<b>Sleep vs Busy-Wait:</b>", ST_BODY))
    story.append(Paragraph("• sleep_ms() and sleep_us() use the timer alarm and will put the processor to sleep (WFI).", ST_BODY))
    story.append(Paragraph("• busy_wait_ms() blocks the CPU in a tight loop.", ST_BODY))
    story.append(Paragraph("<b>FreeRTOS Note:</b> When using FreeRTOS tasks, you should generally use <b>vTaskDelay()</b> instead of sleep_ms() so other tasks can run.", ST_BODY))
    story.append(Spacer(1, 4*mm))

    apis = [
        ("sleep_ms", 
         "Delays execution for the specified milliseconds by sleeping the core.<br/><b>Note:</b> Lower power than busy-wait, but stalls the current core.",
         "void sleep_ms(uint32_t ms);",
         [("ms", "uint32_t", "Milliseconds to sleep")], "None"),
        ("sleep_us", 
         "Delays execution for the specified microseconds.",
         "void sleep_us(uint64_t us);",
         [("us", "uint64_t", "Microseconds to sleep")], "None"),
        ("busy_wait_ms", 
         "Delays execution using a polling loop.",
         "void busy_wait_ms(uint32_t ms);",
         [("ms", "uint32_t", "Milliseconds to wait")], "None"),
        ("busy_wait_us", 
         "Delays execution using a polling loop for strict sub-millisecond timing.",
         "void busy_wait_us(uint64_t us);",
         [("us", "uint64_t", "Microseconds to wait")], "None")
    ]
    for a in apis: story += api_entry(*a)
    story.append(PageBreak())

    # ---------------------------------------------------------
    # 3. UART Workflow
    # ---------------------------------------------------------
    story += section_header("3. UART Workflow")
    story.append(Paragraph("Typical steps for UART:", ST_BODY))
    story.append(Paragraph("1. Initialize UART with desired baud rate using uart_init().", ST_BODY))
    story.append(Paragraph("2. Configure GPIO pins for UART function using gpio_set_function().", ST_BODY))
    story.append(Paragraph("3. Configure baud rate and format (data bits, stop bits, parity).", ST_BODY))
    story.append(Paragraph("4. Enable/disable FIFO if needed.", ST_BODY))
    story.append(Paragraph("5. Read and write data.", ST_BODY))
    story.append(Paragraph("<b>Example:</b>", ST_BODY))
    story.append(Paragraph("uart_init(uart0, 115200);<br/>gpio_set_function(0, GPIO_FUNC_UART); // TX<br/>gpio_set_function(1, GPIO_FUNC_UART); // RX", ST_MONO))
    story.append(Spacer(1, 4*mm))

    apis = [
        ("uart_init", 
         "Initializes a UART peripheral and sets the baud rate.",
         "uint uart_init(uart_inst_t *uart, uint baudrate);",
         [("uart", "uart_inst_t*", "uart0 or uart1"), ("baudrate", "uint", "Baud rate (e.g. 115200)")], "Actual baud rate set"),
        ("uart_set_format", 
         "Configures data bits, stop bits, and parity.<br/><b>Note:</b> Default is 8N1. Only call if you need a different format.",
         "void uart_set_format(uart_inst_t *uart, uint data_bits, uint stop_bits, uart_parity_t parity);",
         [("uart", "uart_inst_t*", "UART instance"), ("data_bits", "uint", "Typically 8"), ("stop_bits", "uint", "1 or 2"), ("parity", "uart_parity_t", "UART_PARITY_NONE/EVEN/ODD")], "None"),
        ("uart_set_fifo_enabled", 
         "Enables or disables the hardware FIFOs.",
         "void uart_set_fifo_enabled(uart_inst_t *uart, bool enabled);",
         [("uart", "uart_inst_t*", "UART instance"), ("enabled", "bool", "true to enable")], "None"),
        ("uart_write_blocking", 
         "Writes a buffer of bytes to the UART, blocking until complete.",
         "void uart_write_blocking(uart_inst_t *uart, const uint8_t *src, size_t len);",
         [("uart", "uart_inst_t*", "UART instance"), ("src", "const uint8_t*", "Data buffer"), ("len", "size_t", "Number of bytes")], "None"),
        ("uart_read_blocking", 
         "Reads bytes from the UART, blocking until requested amount is received.<br/><b>Mistake:</b> Will hang indefinitely if bytes are not received.",
         "void uart_read_blocking(uart_inst_t *uart, uint8_t *dst, size_t len);",
         [("uart", "uart_inst_t*", "UART instance"), ("dst", "uint8_t*", "Buffer"), ("len", "size_t", "Bytes to read")], "None"),
        ("uart_is_readable", 
         "Checks if there is data available to be read in the RX FIFO.",
         "bool uart_is_readable(uart_inst_t *uart);",
         [("uart", "uart_inst_t*", "UART instance")], "true if data is available"),
        ("uart_is_writable", 
         "Checks if there is space available in the TX FIFO to write data.",
         "bool uart_is_writable(uart_inst_t *uart);",
         [("uart", "uart_inst_t*", "UART instance")], "true if space is available")
    ]
    for a in apis: story += api_entry(*a)
    story.append(PageBreak())

    # ---------------------------------------------------------
    # 4. SPI Workflow
    # ---------------------------------------------------------
    story += section_header("4. SPI Workflow")
    story.append(Paragraph("Typical steps for SPI:", ST_BODY))
    story.append(Paragraph("1. Initialize SPI peripheral using spi_init().", ST_BODY))
    story.append(Paragraph("2. Configure SPI GPIO pins (SCK, TX/MOSI, RX/MISO) using gpio_set_function().", ST_BODY))
    story.append(Paragraph("3. Configure SPI format (data bits, CPOL, CPHA).", ST_BODY))
    story.append(Paragraph("4. Configure chip select GPIO (usually standard GPIO output, not hardware CS).", ST_BODY))
    story.append(Paragraph("5. Transfer data.", ST_BODY))
    story.append(Paragraph("<b>Example:</b>", ST_BODY))
    story.append(Paragraph("spi_init(spi0, 1000 * 1000); // 1MHz<br/>gpio_set_function(18, GPIO_FUNC_SPI); // SCK<br/>gpio_set_function(19, GPIO_FUNC_SPI); // TX", ST_MONO))
    story.append(Spacer(1, 4*mm))

    apis = [
        ("spi_init", 
         "Initializes the SPI peripheral and sets the baud rate.",
         "uint spi_init(spi_inst_t *spi, uint baudrate);",
         [("spi", "spi_inst_t*", "spi0 or spi1"), ("baudrate", "uint", "Baud rate in Hz")], "Actual baud rate set"),
        ("spi_set_format", 
         "Configures data size and SPI clock phase/polarity.<br/><b>Note:</b> Default is 8 data bits, CPOL=0, CPHA=0.",
         "void spi_set_format(spi_inst_t *spi, uint data_bits, spi_cpol_t cpol, spi_cpha_t cpha, spi_order_t order);",
         [("spi", "spi_inst_t*", "SPI instance"), ("data_bits", "uint", "Usually 8"), ("cpol", "spi_cpol_t", "SPI_CPOL_0 or 1"), ("cpha", "spi_cpha_t", "SPI_CPHA_0 or 1"), ("order", "spi_order_t", "SPI_MSB_FIRST / LSB")], "None"),
        ("spi_write_blocking", 
         "Writes data to the SPI bus, blocking until complete.<br/><b>Mistake:</b> Discards data received concurrently.",
         "int spi_write_blocking(spi_inst_t *spi, const uint8_t *src, size_t len);",
         [("spi", "spi_inst_t*", "SPI instance"), ("src", "const uint8_t*", "Buffer"), ("len", "size_t", "Length")], "Number of bytes written"),
        ("spi_read_blocking", 
         "Reads data from the SPI bus by writing repeated dummy bytes (default 0).",
         "int spi_read_blocking(spi_inst_t *spi, uint8_t repeated_tx_data, uint8_t *dst, size_t len);",
         [("spi", "spi_inst_t*", "SPI instance"), ("repeated_tx_data", "uint8_t", "Dummy byte (usually 0)"), ("dst", "uint8_t*", "Buffer"), ("len", "size_t", "Length")], "Number of bytes read"),
        ("spi_write_read_blocking", 
         "Simultaneously writes and reads data on the full-duplex SPI bus.",
         "int spi_write_read_blocking(spi_inst_t *spi, const uint8_t *src, uint8_t *dst, size_t len);",
         [("spi", "spi_inst_t*", "SPI instance"), ("src", "const uint8_t*", "TX Buffer"), ("dst", "uint8_t*", "RX Buffer"), ("len", "size_t", "Length")], "Number of bytes exchanged")
    ]
    for a in apis: story += api_entry(*a)
    story.append(PageBreak())

    # ---------------------------------------------------------
    # 5. I2C Workflow
    # ---------------------------------------------------------
    story += section_header("5. I2C Workflow")
    story.append(Paragraph("Typical steps for I2C:", ST_BODY))
    story.append(Paragraph("1. Initialize I2C using i2c_init().", ST_BODY))
    story.append(Paragraph("2. Configure SDA and SCL pins using gpio_set_function().", ST_BODY))
    story.append(Paragraph("3. Enable pull-ups on SDA/SCL using gpio_pull_up() if external resistors are absent.", ST_BODY))
    story.append(Paragraph("4. Read/write using blocking APIs.", ST_BODY))
    story.append(Paragraph("<b>Example:</b>", ST_BODY))
    story.append(Paragraph("i2c_init(i2c0, 400 * 1000); // 400kHz<br/>gpio_set_function(4, GPIO_FUNC_I2C); // SDA<br/>gpio_set_function(5, GPIO_FUNC_I2C); // SCL<br/>gpio_pull_up(4); gpio_pull_up(5);", ST_MONO))
    story.append(Spacer(1, 4*mm))

    apis = [
        ("i2c_init", 
         "Initializes the I2C peripheral and sets the baud rate.",
         "uint i2c_init(i2c_inst_t *i2c, uint baudrate);",
         [("i2c", "i2c_inst_t*", "i2c0 or i2c1"), ("baudrate", "uint", "Baud rate in Hz (e.g. 400000)")], "Actual baud rate set"),
        ("i2c_write_blocking", 
         "Writes to an I2C device.",
         "int i2c_write_blocking(i2c_inst_t *i2c, uint8_t addr, const uint8_t *src, size_t len, bool nostop);",
         [("i2c", "i2c_inst_t*", "I2C instance"), ("addr", "uint8_t", "7-bit device address"), ("src", "const uint8_t*", "Buffer"), ("len", "size_t", "Length"), ("nostop", "bool", "true to hold bus (no STOP) for repeated START")], "Bytes written, or PICO_ERROR_GENERIC"),
        ("i2c_read_blocking", 
         "Reads from an I2C device.",
         "int i2c_read_blocking(i2c_inst_t *i2c, uint8_t addr, uint8_t *dst, size_t len, bool nostop);",
         [("i2c", "i2c_inst_t*", "I2C instance"), ("addr", "uint8_t", "7-bit device address"), ("dst", "uint8_t*", "Buffer"), ("len", "size_t", "Length"), ("nostop", "bool", "true to hold bus")], "Bytes read, or PICO_ERROR_GENERIC")
    ]
    for a in apis: story += api_entry(*a)
    story.append(PageBreak())

    # ---------------------------------------------------------
    # 6. ADC Workflow
    # ---------------------------------------------------------
    story += section_header("6. ADC Workflow")
    story.append(Paragraph("Typical steps for ADC:", ST_BODY))
    story.append(Paragraph("1. Initialize ADC hardware using adc_init().", ST_BODY))
    story.append(Paragraph("2. Configure GPIO for ADC using adc_gpio_init().", ST_BODY))
    story.append(Paragraph("3. Select ADC channel using adc_select_input().", ST_BODY))
    story.append(Paragraph("4. Read conversion using adc_read().", ST_BODY))
    story.append(Paragraph("<b>Mistake:</b> Do not use ADC GPIOs as digital GPIOs while operating as ADC inputs. Do not call gpio_init() on an ADC pin, use adc_gpio_init() instead.", ST_BODY))
    story.append(Spacer(1, 4*mm))

    apis = [
        ("adc_init", 
         "Initializes the ADC hardware.",
         "void adc_init(void);",
         [], "None"),
        ("adc_gpio_init", 
         "Prepares a GPIO for use with ADC.<br/><b>Note:</b> Disables digital input and pulls on the pin.",
         "void adc_gpio_init(uint gpio);",
         [("gpio", "uint", "ADC GPIO (26-29)")], "None"),
        ("adc_select_input", 
         "Selects the active ADC input channel.",
         "void adc_select_input(uint input);",
         [("input", "uint", "Channel 0-3 (GPIO 26-29), 4 (Temp Sensor)")], "None"),
        ("adc_read", 
         "Performs a single blocking ADC conversion.",
         "uint16_t adc_read(void);",
         [], "12-bit ADC result (0-4095)")
    ]
    for a in apis: story += api_entry(*a)
    story.append(PageBreak())

    # ---------------------------------------------------------
    # 7. PWM Workflow
    # ---------------------------------------------------------
    story += section_header("7. PWM Workflow")
    story.append(Paragraph("Typical steps for PWM:", ST_BODY))
    story.append(Paragraph("1. Configure GPIO for PWM using gpio_set_function(pin, GPIO_FUNC_PWM).", ST_BODY))
    story.append(Paragraph("2. Determine PWM slice for the GPIO using pwm_gpio_to_slice_num().", ST_BODY))
    story.append(Paragraph("3. Configure wrap value (frequency) using pwm_set_wrap().", ST_BODY))
    story.append(Paragraph("4. Set duty cycle using pwm_set_chan_level().", ST_BODY))
    story.append(Paragraph("5. Enable PWM slice using pwm_set_enabled().", ST_BODY))
    story.append(Paragraph("<b>Example:</b>", ST_BODY))
    story.append(Paragraph("gpio_set_function(2, GPIO_FUNC_PWM);<br/>uint slice = pwm_gpio_to_slice_num(2);<br/>pwm_set_wrap(slice, 255);<br/>pwm_set_chan_level(slice, PWM_CHAN_A, 128);<br/>pwm_set_enabled(slice, true);", ST_MONO))
    story.append(Spacer(1, 4*mm))

    apis = [
        ("pwm_gpio_to_slice_num", 
         "Returns the PWM slice number connected to a given GPIO.",
         "uint pwm_gpio_to_slice_num(uint gpio);",
         [("gpio", "uint", "GPIO number")], "Slice number (0-7)"),
        ("pwm_set_wrap", 
         "Sets the highest value the counter will reach before wrapping.<br/><b>Note:</b> This determines the PWM period/frequency.",
         "void pwm_set_wrap(uint slice_num, uint16_t wrap);",
         [("slice_num", "uint", "PWM slice"), ("wrap", "uint16_t", "Wrap value")], "None"),
        ("pwm_set_chan_level", 
         "Sets the PWM duty cycle for a specific channel on a slice.",
         "void pwm_set_chan_level(uint slice_num, uint chan, uint16_t level);",
         [("slice_num", "uint", "PWM slice"), ("chan", "uint", "PWM_CHAN_A or PWM_CHAN_B"), ("level", "uint16_t", "Compare value (duty cycle)")], "None"),
        ("pwm_set_enabled", 
         "Enables or disables a PWM slice.",
         "void pwm_set_enabled(uint slice_num, bool enabled);",
         [("slice_num", "uint", "PWM slice"), ("enabled", "bool", "true to run")], "None")
    ]
    for a in apis: story += api_entry(*a)
    story.append(PageBreak())

    # ---------------------------------------------------------
    # 8. Interrupt Workflow
    # ---------------------------------------------------------
    story += section_header("8. Interrupt Workflow")
    story.append(Paragraph("Typical steps for Hardware Interrupts:", ST_BODY))
    story.append(Paragraph("1. Register the interrupt handler using irq_set_exclusive_handler().", ST_BODY))
    story.append(Paragraph("2. Enable the interrupt on the peripheral itself.", ST_BODY))
    story.append(Paragraph("3. Enable the interrupt in the NVIC using irq_set_enabled().", ST_BODY))
    story.append(Paragraph("<b>Best Practices:</b> Keep ISRs short! Defer heavy work to the main loop or a FreeRTOS task.", ST_BODY))
    story.append(Spacer(1, 4*mm))

    apis = [
        ("irq_set_exclusive_handler", 
         "Sets a dedicated hardware interrupt handler.<br/><b>Dependency:</b> Call before enabling the interrupt.",
         "void irq_set_exclusive_handler(uint num, irq_handler_t handler);",
         [("num", "uint", "IRQ number (e.g. UART0_IRQ)"), ("handler", "irq_handler_t", "Function pointer")], "None"),
        ("irq_set_enabled", 
         "Enables or disables a specific interrupt at the NVIC (interrupt controller) level.",
         "void irq_set_enabled(uint num, bool enabled);",
         [("num", "uint", "IRQ number"), ("enabled", "bool", "true to enable")], "None")
    ]
    for a in apis: story += api_entry(*a)
    story.append(PageBreak())

    # ---------------------------------------------------------
    # 9. Standard I/O
    # ---------------------------------------------------------
    story += section_header("9. Standard I/O")
    story.append(Paragraph("Standard I/O can be routed to UART or USB CDC (TinyUSB) depending on CMake definitions (pico_enable_stdio_usb / pico_enable_stdio_uart).", ST_BODY))
    story.append(Spacer(1, 4*mm))

    apis = [
        ("stdio_init_all", 
         "Initializes all standard I/O links (UART, USB) configured in the CMake build.<br/><b>Mistake:</b> Failing to call this means printf() goes nowhere.",
         "bool stdio_init_all(void);",
         [], "true if successful"),
        ("printf", 
         "Standard C library print function.<br/><b>Note:</b> Can block if the output buffer (like USB CDC) is full.",
         "int printf(const char *format, ...);",
         [("format", "const char*", "Format string")], "Number of characters printed")
    ]
    for a in apis: story += api_entry(*a)
    story.append(PageBreak())

