import os

pdf_path = "/home/shalin-dev/Documents/pdf.py"
scratch_path = "/home/shalin-dev/Documents/pico/3rd_task/scratch.py"

with open(pdf_path, "r") as f:
    pdf_content = f.read()

with open(scratch_path, "r") as f:
    scratch_content = f.read()

# 1. Insert build_pico_quick_reference before build_pdf
target1 = "from pathlib import Path\n\ndef build_pdf():"
replacement1 = f"from pathlib import Path\n\n{scratch_content}\n\ndef build_pdf():"
pdf_content = pdf_content.replace(target1, replacement1)

# 2. Insert build_pico_quick_reference(story) inside build_pdf
target2 = "    # ── Body sections ────────────────────────────────────────────\n    story.append(platypus.NextPageTemplate('body'))\n\n    sections = ["
replacement2 = "    # ── Body sections ────────────────────────────────────────────\n    story.append(platypus.NextPageTemplate('body'))\n\n    build_pico_quick_reference(story)\n\n    sections = ["
pdf_content = pdf_content.replace(target2, replacement2)

with open(pdf_path, "w") as f:
    f.write(pdf_content)

print("Patch applied successfully.")
